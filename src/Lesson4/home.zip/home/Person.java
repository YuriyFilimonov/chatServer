package ru.gb.jtwo.c_lesson.home;

public class Person {
    public String phone;
    public String email;

    public Person(String phone, String email) {
        this.phone = phone;
        this.email = email;
    }
}
